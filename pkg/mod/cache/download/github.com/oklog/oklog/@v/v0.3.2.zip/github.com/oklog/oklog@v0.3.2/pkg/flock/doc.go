// Package flock implements filesystem locking.
// It was copied from the Prometheus project.
package flock
