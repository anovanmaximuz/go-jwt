// Package amqp implements an AMQP transport.
package amqp
