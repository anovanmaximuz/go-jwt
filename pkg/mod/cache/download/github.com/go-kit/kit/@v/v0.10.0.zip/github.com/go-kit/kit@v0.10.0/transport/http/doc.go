// Package http provides a general purpose HTTP binding for endpoints.
package http
