// Package group aliases github.com/oklog/run.
package group

import (
	"github.com/oklog/run"
)

type Group = run.Group

